import ij.*;
import ij.process.*;
import ij.gui.*;
import ij.plugin.*;

public class Anaglyph_ implements PlugIn {
	/*  by G. Landini, G.Landini at bham.ac.uk
	Creates an anaglyph. stereo pair and depth map out of a topological image and an "in focus" image.
	18/May/2004
	20 Aug 2010 Added some SelectImage statements
	v1.6, 18 Mar 2010. Now it uses the Height-Map name instead of Topology
	==============================================================
	This program is a free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public license
	as published by the Free Software Foundation; either version 2
	of license, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
	General Public License for more details.

	You should have received a copy of the GNU General Public License along
	with this program; if not, write to the Free Software Foundation, Inc.,
	59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
	==============================================================
	*/

	public void run(String arg) {

		IJ.selectWindow("Height-Map");
		ImagePlus imp = WindowManager.getCurrentImage();
		if (imp==null){
			IJ.error("No Height-Map image!");
			return;
		}
		ImageProcessor ip = imp.getProcessor();
		int xe = ip.getWidth();
		int ye = ip.getHeight();
		int x, y, i, levels=0, p, r, g, b, s=-1;
		for (y=0;y<ye;y++){
			for (x=0;x<xe;x++){
				p=(int)ip.getPixelValue(x,y);
				if (p>levels)
					levels=p;
			}
		}
		levels++;

		int hl=levels/2;

		IJ.selectWindow("Output");
		IJ.run("Duplicate...", "title=OnFocus");
		IJ.run("RGB Color");
		ImagePlus imp1 = WindowManager.getCurrentImage();
		if (imp1==null){
			IJ.error("No Output image!");
			return;
		}

		ImageProcessor ip1 = imp1.getProcessor();

		IJ.run("Duplicate...", "title=Stereo");
		IJ.run("Duplicate...", "title=Anaglyph");
		IJ.run("RGB Color");
		ImagePlus imp2 = WindowManager.getCurrentImage();
		ImageProcessor ip2 = imp2.getProcessor();
				//r[x][y]=((p & 0xff0000) >> 16);
				//g[x][y]=((p & 0x00ff00) >> 8);
				//b[x][y]=(p & 0x0000ff);
		IJ.showStatus("Making cyan-red anaglyph");

		for (i=0;i<levels;i++){
			IJ.showProgress((double)i/levels);
			for (y=0;y<ye;y++){
				for (x=i;x<xe-i;x++){
					p=ip2.getPixel(x,y);
					g=((p & 0x00ff00) >> 8);
					b=(p & 0x0000ff);
					r = (ip1.getPixel(x+i,y) & 0xff0000)>>16;
					if (((int)Math.floor(ip.getPixelValue(x,y)+0.5)& 0x0000ff)>=i )
						ip2.putPixel(x+hl, y, ((r & 0xff) <<16)+ ((g & 0xff) << 8)+ (b & 0xff));
				}
			}
		}

		for (i=0;i<levels;i++){
			IJ.showProgress((double)i/levels);
			for (y=0;y<ye;y++){
				for (x=i;x<xe-i;x++){
					g=(ip1.getPixel(x-i,y) & 0x00ff00) >>8;
					b=(ip1.getPixel(x-i,y) & 0x0000ff);
					r = (ip2.getPixel(x,y) & 0xff0000)>>16;
					if (((int)Math.floor(ip.getPixelValue(x,y)+0.5)& 0x0000ff)>=i )
						ip2.putPixel(x, y, ((r & 0xff) <<16)+ ((g & 0xff) << 8)+ (b & 0xff));
				}
			}
		}
		IJ.showProgress(1.0);
		imp2.updateAndDraw();

		GenericDialog gd = new GenericDialog("Anaglyph", IJ.getInstance());
		gd.addMessage("Anaglyph 1.6 by  G. Landini.\nCreates an anaplyph, stereo pair or distance\nmap based on the \'Height-Map\' & \'Output\' images\nproduced with the Extended Depth of Focus plugin.");

		gd.addCheckbox("Red-Green anaglyph",false);
		gd.addCheckbox("Swap view sides",false);
		gd.addCheckbox("Stereo pair",false);
		gd.addCheckbox("Distance map",false);
		gd.addNumericField ("Map range", 25, 0);

		gd.showDialog();
		if (gd.wasCanceled())
			return;

		boolean green = gd.getNextBoolean ();
		boolean swap = gd.getNextBoolean ();
		boolean stereo = gd.getNextBoolean ();
		boolean dmap = gd.getNextBoolean ();
		int max = (int) gd.getNextNumber();



		if (swap){
			IJ.showStatus("Swapping view sides");
			s=1;
			for (i=0;i<levels;i++){
				IJ.showProgress((double)i/levels);
				for (y=0;y<ye;y++){
					for (x=i;x<xe-i;x++){
						p=ip2.getPixel(x,y);
						g=((p & 0x00ff00) >> 8);
						b=(p & 0x0000ff);
						r = (ip1.getPixel(x-i,y) & 0xff0000)>>16;
						if (((int)Math.floor(ip.getPixelValue(x,y)+0.5)& 0x0000ff)>=i )
							ip2.putPixel(x-hl, y, ((r & 0xff) <<16)+ ((g & 0xff) << 8)+ (b & 0xff));
					}
				}
			}

			for (i=0;i<levels;i++){
				IJ.showProgress((double)i/levels);
				for (y=0;y<ye;y++){
					for (x=i;x<xe-i;x++){
						g=(ip1.getPixel(x+i,y) & 0x00ff00) >>8;
						b=(ip1.getPixel(x+i,y) & 0x0000ff);
						r = (ip2.getPixel(x,y) & 0xff0000)>>16;
						if (((int)Math.floor(ip.getPixelValue(x,y)+0.5)& 0x0000ff)>=i )
							ip2.putPixel(x, y, ((r & 0xff) <<16)+ ((g & 0xff) << 8)+ (b & 0xff));
					}
				}
			}
		imp2.updateAndDraw();
		IJ.showProgress(1.0);
		}

		if (green){
			IJ.showStatus("Making green-red anaglyph");

			for (y=0;y<ye;y++){
				for (x=0;x<xe;x++){
					p=ip2.getPixel(x,y);
					r= (p & 0xff0000)>>16;
					g=(p & 0x00ff00)>>8;
					ip2.putPixel(x, y, ((r & 0xff) <<16)+ ((g & 0xff) << 8)+ (0 & 0xff));
				}
			}
			imp2.updateAndDraw();
		}

		if (stereo){
			IJ.showStatus("Making stereo-pair");
			IJ.selectWindow("OnFocus");
			imp1 = WindowManager.getCurrentImage();
			ip1 = imp1.getProcessor();

			IJ.selectWindow("Stereo");
			imp2 = WindowManager.getCurrentImage();
			ip2 = imp2.getProcessor();

			for (i=0;i<levels;i++){
				IJ.showProgress((double)i/levels);
				for (y=0;y<ye;y++){
					for (x=i;x<xe-i;x++){
						p=ip1.getPixel(x+i*s,y);
						if (((int)Math.floor(ip.getPixelValue(x,y)+0.5)& 0x0000ff)>=i )
							ip2.putPixel(x, y, p);
					}
				}
			}
			imp2.updateAndDraw();

			IJ.run("Add Slice");
			imp2 = WindowManager.getCurrentImage();
			ip2 = imp2.getProcessor();
			for (i=0;i<levels;i++){
				IJ.showProgress((double)i/levels);
				for (y=0;y<ye;y++){
					for (x=i;x<xe-i;x++){
						p=ip1.getPixel(x-i*s,y);
						if (((int)Math.floor(ip.getPixelValue(x,y)+0.5)& 0x0000ff)>=i )
							ip2.putPixel(x, y, p);
					}
				}
			}
			IJ.showProgress(1.0);
			imp2.updateAndDraw();
			IJ.run("Make Montage...", "columns=2 rows=1 scale=1 first=1 last=2 increment=1 border=10 ");
			IJ.run("Rename...", "title='Stereo pair'");
		}
		IJ.selectWindow("Stereo");
		IJ.run("Close");
		IJ.selectWindow("OnFocus");
		IJ.run("Close");


		if (dmap){
			IJ.showStatus("Making depth map");
			IJ.selectWindow("Output");
			IJ.run("Duplicate...", "title='Depth Map'");
			IJ.selectWindow("Depth Map");
			IJ.run("8-bit");
			IJ.run("RGB Color");
			IJ.run("HSB Stack");
			IJ.run("Next Slice [>]");
			IJ.run("Select All");
			IJ.run("Invert", "slice");
			IJ.run("Select None");
			IJ.run("Previous Slice [<]");
			IJ.selectWindow("Height-Map");
			IJ.run("Duplicate...", "title=Height-Map-copy");
			IJ.selectWindow("Height-Map-copy");
			IJ.run("Conversions...", "  ");
			IJ.run("8-bit");
			IJ.run("Conversions...", "scale ");
			IJ.run("Copy");
			IJ.selectWindow("Depth Map");
			IJ.run("Paste");
			// if there are too many or too few slices, then the Max value below may need adjustment.
			IJ.setMinAndMax(0, max);
			IJ.run("Apply LUT", "slice");
			IJ.run("RGB Color");
			IJ.selectWindow("Height-Map-copy");
			IJ.run("Close");
		}
	}
}
